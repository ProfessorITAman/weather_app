package com.sultan.weather.view

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.sultan.weather.R
import com.sultan.weather.databinding.ActivityMainBinding
import com.sultan.weather.model.models.WeatherResponse
import com.sultan.weather.presenter.WeatherContract
import com.sultan.weather.presenter.WeatherPresenter

class MainActivity : AppCompatActivity(), WeatherContract.View{

    private lateinit var binding : ActivityMainBinding
    private val presenter by lazy { WeatherPresenter(this) }

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        presenter.loadWeather("London")
        initialize()

    }
    private fun initialize() = with(binding) {
        ArrayAdapter.createFromResource(
            root.context,
            R.array.country_list,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            countries.adapter = adapter
        }

        countries.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedItem = parent.getItemAtPosition(position).toString()
                presenter.loadWeather(selectedItem)
                Toast.makeText(this@MainActivity, "Вы выбрали: $selectedItem", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Не выбрано ничего
            }
        }
    }

    override fun showWeather(weatherResponse: WeatherResponse) = with(binding){
        temp.text = weatherResponse.current.tempC.toString()
        wind.text = weatherResponse.current.windKph.toString()
        humidity.text = weatherResponse.current.humidity.toString()
        rain.text = weatherResponse.current.precipMm.toInt().toString()
    }

    override fun showError(error: String) {
        Toast.makeText(this, error, Toast.LENGTH_SHORT).show()
    }
}