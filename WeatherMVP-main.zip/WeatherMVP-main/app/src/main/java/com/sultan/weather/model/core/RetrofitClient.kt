package com.sultan.weather.model.core

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import com.sultan.weather.model.service.WeatherService
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit

object RetrofitClient  {
    private const val BASE_URL = "https://api.weatherapi.com/v1/"

    // это перехватчик
    private val logingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    //  Это точка вызова в сеть интернета
    private val httpClient = OkHttpClient.Builder()
        .addInterceptor(logingInterceptor)
        .build()

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    val retrofitService : WeatherService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(httpClient)
            .addConverterFactory(Json.asConverterFactory("*/*".toMediaType()))
            .build()
            .create(WeatherService::class.java)
    }
}