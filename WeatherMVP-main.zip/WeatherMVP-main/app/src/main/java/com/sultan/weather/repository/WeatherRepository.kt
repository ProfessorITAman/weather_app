package com.sultan.weather.repository

import com.sultan.weather.model.core.RetrofitClient

class WeatherRepository {
    suspend fun getWeather(
        location : String
    ) = RetrofitClient.retrofitService.getCurrentWeather(
            key = "0e95f1ebae5f4d988d784226251104",
            q = location
        )
}