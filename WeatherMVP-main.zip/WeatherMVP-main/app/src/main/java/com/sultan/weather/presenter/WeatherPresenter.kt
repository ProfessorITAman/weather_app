package com.sultan.weather.presenter

import android.util.Log
import com.sultan.weather.repository.WeatherRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class WeatherPresenter(
    var view : WeatherContract.View?,
) : WeatherContract.Presenter {

    // создаем объект репазиторий
    val repository = WeatherRepository()
    // новый поток
    private val job = Job()
    // область видомости потока
    private val scope = CoroutineScope(Dispatchers.Main + job)

    override fun loadWeather(location: String) {
        // Запуск потока
        scope.launch {
            try {
                // получить погоду
                val weather = repository.getWeather(location)
                view?.showWeather(weather)
            } catch (e : Exception) {
                Log.e("ololo", e.message.toString())
                view?.showError(e.message ?: "Unknown error!")
            }
        }
    }

    override fun onDestroy() {
        // обнулить
        view = null
        // завершить поток
        job.cancel()
    }
}