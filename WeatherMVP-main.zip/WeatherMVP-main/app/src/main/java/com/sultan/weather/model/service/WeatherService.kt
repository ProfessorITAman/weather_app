package com.sultan.weather.model.service

import com.sultan.weather.model.models.WeatherResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherService {
    @GET("current.json")
    suspend fun  getCurrentWeather(
        @Query("key") key: String,
        @Query("q") q: String,
    ) : WeatherResponse
 }