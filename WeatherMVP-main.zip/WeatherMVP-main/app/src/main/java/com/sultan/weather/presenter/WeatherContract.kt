package com.sultan.weather.presenter

import com.sultan.weather.model.models.WeatherResponse

interface WeatherContract {
    interface View {
        fun showWeather(weatherResponse: WeatherResponse)
        fun showError(error : String)
    }

    interface Presenter {
        fun loadWeather(location : String)
        fun onDestroy()
    }
}